9th September 2010

STAGE DLL 2010
For Orbiter2010-P1

Installation
Extract into your Orbiter directory, make sure the folder structure is preserved
(or extract to a location of your choice and manually place the stage.dll in your Orbiter/Modules/ folder)

What's This Add-On?
This is a quick fix for the stage.dll that is included in Vinka's "Multistage2.dll" package.
Vinka's stage.dll does not function correctly with Orbiter2010 (no mesh/visuals).

Keep your eyes open for an updated version by Vinka soon!

Regards,
BrianJ